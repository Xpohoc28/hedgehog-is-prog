import flet as fl 
from calculations import stddev, mean, absolute_value, validate_input, validate_n_input, otnos_pog, DeltaX
import webbrowser


def open_link(event):
    webbrowser.open('https://vk.com/club225726681', new=2)
       

       
# Основная функция приложения
def main(page: fl.Page):
    
    page.title = "DeltaX"
    page.window_width = 335        # window's width is 200 px
    page.window_height = 735       # window's height is 200 px
    page.adaptive = True
    #page.update()
    
    #page.window_resizable = False  # window is not resizable
    page.theme_mode = 'dark'
    page_vertical_alignment = fl.MainAxisAlignment.CENTER
    page.scroll = "both"
    # Функция для обработки нажатия на кнопку "Рассчитать"
    def on_column_scroll(e: fl.OnScrollEvent):
        print(
            f"Type: {e.event_type}, pixels: {e.pixels}, min_scroll_extent: {e.min_scroll_extent}, max_scroll_extent: {e.max_scroll_extent}"
        )

    def calculate(e):
        error_output.text = ''
        error_output.visible = False

        try:
            n_value = validate_n_input(n_input.value)
            input_values = values_input.value.split()
            if len(input_values) != n_value:
                raise ValueError("Введено неверное количество чисел.")

            values = [validate_input(v) for v in input_values]

            t_values = {2: 3, 3: 4.3, 4: 5, 5: 6, 6: 7, 7: 8, 8: 9, 9: 10, 10: 20}
            t = t_values.get(n_value, 2)

            a_sys_value = validate_input(a_sys_input.value)
            n_value = validate_n_input(n_input.value)
            mean_value = mean(values)
            standard_deviation = stddev(values, mean_value)
            rounded_std_deviation_t = round(standard_deviation * t, 2)
            absolute_std_deviation_t = absolute_value(a_sys_value, rounded_std_deviation_t)
            D = DeltaX(standard_deviation, a_sys_value)
            E = otnos_pog(D, mean_value)
            



            mean_output.value = f"{mean_value}"
            std_dev_output.value = f"{standard_deviation}"
            std_dev_t_output.value = f"{rounded_std_deviation_t}"
            abs_value_output.value = f"{absolute_std_deviation_t}"
            
            D_output.value = f"{D}"
            E_output.value = f"{E} ≈ {E*100:.3f}%" #перевод в проценты. округление до 3 знаков после запятой
            #DeltaX_output.value = f"{Delta}"

            try:
                page.update()
            except Exception as ex:
                error_output.value = str(ex)
                error_output.visible = True
                page.update()

        except Exception as ex:
            error_output.value = str(ex)
            error_output.visible = True
            mean_output.value = ""
            std_dev_output.value = ""
            std_dev_t_output.value = ""
            abs_value_output.value = ""
            E_output.value = ""
            D_output.value = ""
            
            page.update()

        except ValueError as ex:
            error_output.text = str(ex)
            error_output.visible = True
            page.update()

    
    
    # Функция для обработки нажатия на кнопку "Сбросить"
    def reset(e):
        # Очистка всех текстовых полей
        n_input.value = ""
        values_input.value = ""
        mean_output.value = ""
        std_dev_output.value = ""
        std_dev_t_output.value = ""
        abs_value_output.value = ""
        D_output.value = ""
        E_output.value = ""
        error_output.value = ""
        error_output.visible = False  # Делаем текстовое поле "Ошибка" невидимым
        page.update()

    def change_theme(e):
        # Change the app theme based on the selection
        page.theme_mode = 'light' if page.theme_mode == 'dark' else 'dark'
        page.update()
        
    # Создание текстовых полей для ввода данных
    n_input = fl.TextField(label="Введите количество чисел N:", value="10")
    values_input = fl.TextField(label="Введите числа через пробел:", value="1 2 3 4 5 6 7 8 9 10")
    a_sys_input = fl.TextField(label="Введите абсолютное значение систематической погрешности:", value="0.1")
    
    # Создание кнопок для действий
    calculate_button = fl.ElevatedButton(text="Рассчитать", on_click=calculate)
    reset_button = fl.ElevatedButton(text="Сбросить", on_click=reset)
    theme_button = fl.IconButton(fl.icons.SUNNY, on_click = change_theme, width = 200, height = 200)
    link_text = fl.ElevatedButton(text = "Перейти в группу разработчика", on_click = open_link)

    
    # Создание текстовых полей для вывода результатов
    mean_output = fl.TextField(label="x(ср):", value="", read_only=True, width=300, height=50)
    std_dev_output = fl.TextField(label="δx:", value="", read_only=True, width=300, height=50)
    D_output = fl.TextField(label="Δx:", value="", read_only=True, width=300, height=50)
    std_dev_t_output = fl.TextField(label="Δx(ср):", value="", read_only=True, width=300, height=50)
    abs_value_output = fl.TextField(label="Δx(абс):", value="", read_only=True, width=300, height=50)
    E_output = fl.TextField(label="E:", value="", read_only=True, width=300, height=50, text_size=14)
    # Создание текстового поля для вывода ошибок, изначально невидимое и Задание размера текста
    error_output = fl.TextField(label="Ошибка:", value="", multiline=True, read_only=True, visible=False, width=300, height=50, text_size=14) 
    # Создание горизонтального ряда для кнопок
    buttons_row = fl.Row([calculate_button, reset_button])
    
 
    panel_cal =  fl.Column([fl.Row(
            [
                fl.Column([
                    # Создание текстовых полей для ввода данных
                    n_input ,
                    values_input ,
                    a_sys_input ,
                    fl.Row([
                        # Создание кнопок для действий
                        calculate_button ,
                        reset_button,
                        ]),
                    # Создание текстовых полей для вывода результатов
                    error_output,
                    mean_output ,
                    D_output,
                    std_dev_output ,
                    std_dev_t_output,
                    abs_value_output,
                    E_output
                    ])])], scroll=fl.ScrollMode.HIDDEN, expand=1)
       # , vertical_alignment=fl.CrossAxisAlignment.START


     
    panel_settings = fl.Row(
            [
               
                fl.Column([
                    theme_button, link_text
                    
                ],expand=True, alignment=fl.MainAxisAlignment.CENTER, 
                horizontal_alignment=fl.CrossAxisAlignment.CENTER,
                 )], expand=0)

    def navigate(e):
        index = page.navigation_bar.selected_index
        page.clean()

        if index == 0: page.add(panel_cal)
        elif index == 1: page.add(panel_settings)


    page.navigation_bar = fl.NavigationBar(
    destinations=[
            fl.NavigationDestination(icon=fl.icons.CALCULATE, label='Рассчет погрешностей'),
            fl.NavigationDestination(icon=fl.icons.SETTINGS, label='Настройки')
        ], on_change = navigate
    )
    

    page.add(panel_cal)
      

# Запуск приложения
fl.app(target=main, view = fl.AppView.FLET_APP)