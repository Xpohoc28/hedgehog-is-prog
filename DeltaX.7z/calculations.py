import math

def stddev(values, mean_value):
    return math.sqrt(sum((x - mean_value)**2 for x in values) / (len(values) * (len(values) - 1)))

def mean(values):
    return round(sum(values) / len(values), 2)

def absolute_value(a_sys, std_deviation_t):
    return math.sqrt(a_sys**2 + std_deviation_t ** 2)

def otnos_pog(Delta, mean_value): 
    return Delta/mean_value

def DeltaX(standard_deviation, a_sys_value):
    return math.sqrt(a_sys_value**2 + standard_deviation**2)

def validate_input(input_value):
    input_value = input_value.strip()
    if not input_value:
        raise ValueError("Введите систематическую погрешность")
    return float(input_value.replace(',', '.'))

def validate_n_input(input_value):
    input_value = input_value.strip()
    if not input_value:
        raise ValueError("Поле количества чисел N не может быть пустым.")
    if not input_value.isdigit():
        raise ValueError(f"Введен некорректный символ: '{input_value}'. Введите целое число")
    return int(input_value)